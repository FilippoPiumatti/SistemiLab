﻿namespace Es_11___Stadio
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblEst = new System.Windows.Forms.Label();
            this.lblNord = new System.Windows.Forms.Label();
            this.lblOvest = new System.Windows.Forms.Label();
            this.lblSud = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAvvia = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtPostiDisponibili = new System.Windows.Forms.TextBox();
            this.txtPotenzialiClienti = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Es_11___Stadio.Properties.Resources.img;
            this.pictureBox1.Location = new System.Drawing.Point(29, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(719, 562);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblEst
            // 
            this.lblEst.AutoSize = true;
            this.lblEst.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEst.Location = new System.Drawing.Point(592, 298);
            this.lblEst.Name = "lblEst";
            this.lblEst.Size = new System.Drawing.Size(91, 24);
            this.lblEst.TabIndex = 1;
            this.lblEst.Text = "BIGL. EST";
            this.lblEst.Click += new System.EventHandler(this.lblEst_Click);
            // 
            // lblNord
            // 
            this.lblNord.AutoSize = true;
            this.lblNord.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNord.Location = new System.Drawing.Point(332, 71);
            this.lblNord.Name = "lblNord";
            this.lblNord.Size = new System.Drawing.Size(113, 24);
            this.lblNord.TabIndex = 2;
            this.lblNord.Text = "BIGL. NORD";
            this.lblNord.Click += new System.EventHandler(this.lblNord_Click);
            // 
            // lblOvest
            // 
            this.lblOvest.AutoSize = true;
            this.lblOvest.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvest.Location = new System.Drawing.Point(44, 298);
            this.lblOvest.Name = "lblOvest";
            this.lblOvest.Size = new System.Drawing.Size(117, 24);
            this.lblOvest.TabIndex = 3;
            this.lblOvest.Text = "BIGL. OVEST";
            this.lblOvest.Click += new System.EventHandler(this.lblOvest_Click);
            // 
            // lblSud
            // 
            this.lblSud.AutoSize = true;
            this.lblSud.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSud.Location = new System.Drawing.Point(345, 551);
            this.lblSud.Name = "lblSud";
            this.lblSud.Size = new System.Drawing.Size(96, 24);
            this.lblSud.TabIndex = 4;
            this.lblSud.Text = "BIGL. SUD";
            this.lblSud.Click += new System.EventHandler(this.lblSud_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(790, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 26);
            this.label1.TabIndex = 7;
            this.label1.Text = "POSTI DISPONIBILI:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(790, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 26);
            this.label2.TabIndex = 9;
            this.label2.Text = "POTENZIALI CLIENTI:";
            // 
            // btnAvvia
            // 
            this.btnAvvia.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAvvia.Location = new System.Drawing.Point(795, 188);
            this.btnAvvia.Name = "btnAvvia";
            this.btnAvvia.Size = new System.Drawing.Size(207, 29);
            this.btnAvvia.TabIndex = 11;
            this.btnAvvia.Text = "AVVIA ACQUISTO";
            this.btnAvvia.UseVisualStyleBackColor = true;
            this.btnAvvia.Click += new System.EventHandler(this.btnAvvia_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(792, 357);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(72, 18);
            this.lblStatus.TabIndex = 12;
            this.lblStatus.Text = "[lblStatus]";
            // 
            // txtPostiDisponibili
            // 
            this.txtPostiDisponibili.Location = new System.Drawing.Point(795, 63);
            this.txtPostiDisponibili.Name = "txtPostiDisponibili";
            this.txtPostiDisponibili.Size = new System.Drawing.Size(100, 22);
            this.txtPostiDisponibili.TabIndex = 13;
            // 
            // txtPotenzialiClienti
            // 
            this.txtPotenzialiClienti.Location = new System.Drawing.Point(795, 144);
            this.txtPotenzialiClienti.Name = "txtPotenzialiClienti";
            this.txtPotenzialiClienti.Size = new System.Drawing.Size(100, 22);
            this.txtPotenzialiClienti.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 626);
            this.Controls.Add(this.txtPotenzialiClienti);
            this.Controls.Add(this.txtPostiDisponibili);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnAvvia);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSud);
            this.Controls.Add(this.lblOvest);
            this.Controls.Add(this.lblNord);
            this.Controls.Add(this.lblEst);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblEst;
        private System.Windows.Forms.Label lblNord;
        private System.Windows.Forms.Label lblOvest;
        private System.Windows.Forms.Label lblSud;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAvvia;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtPostiDisponibili;
        private System.Windows.Forms.TextBox txtPotenzialiClienti;
    }
}

