﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Es_11___Stadio
{
    public partial class Form1 : Form
    {
        const int BIGLIETTERIE = 4;
        public struct Clienti
        {
            public int IdCliente;
            public int IdBiglietteria; //0 nord, 1 sud , 2 est , 3 ovest
            public bool Acquistato;
            public bool Smaltito;
        }
        public Clienti[] Cl;
        
        public struct PostiStadio
        {
            public int IdPosto;
            public bool Occupato;
            public int IdCliente;
        }
        public PostiStadio[] Ps;

         public Random rnd;
         public int numPosti, numClienti;

        volatile object lock_campo = new object();


        public Form1()
        {
            InitializeComponent();
        }

        private void btnAvvia_Click(object sender, EventArgs e)
        {
            rnd = new Random();
            numPosti = Convert.ToInt32(txtPostiDisponibili.Text);
            numClienti = Convert.ToInt32(txtPotenzialiClienti.Text);
            Cl = new Clienti[numClienti];
            Ps = new PostiStadio[numPosti];
            Thread t = new Thread(GestoreBiglietti);
            t.Start();
        }

        private void GestoreBiglietti()
        {
            SetLabel(lblStatus, " ASSEGNO LE CODE... ");

            for (int i = 0; i < Cl.Length; i++)
            {
                Cl[i].IdCliente = i + 1;
                Cl[i].IdBiglietteria = rnd.Next(0, BIGLIETTERIE);
                Cl[i].Acquistato = false;
                Cl[i].Smaltito = false;
            }

            for (int i = 0; i < Ps.Length; i++)
            {
                Ps[i].IdCliente = 0;
                Ps[i].IdPosto = i + 1;
                Ps[i].Occupato = false;
            }

            Thread[] Biglietteria = new Thread[BIGLIETTERIE];

            for (int i = 0; i < BIGLIETTERIE; i++)
            {
                Biglietteria[i] = new Thread(SmatisciCoda);
                Biglietteria[i].Name = i.ToString();
                Thread.Sleep(1000);
                SetLabel(lblStatus, " BIGLIETTERIA APERTA!!! ");
                Biglietteria[i].Start();
            }
            for (int i = 0; i < BIGLIETTERIE; i++)
            {
                Biglietteria[i].Join();
            }
            SetLabel(lblStatus, " VENDITA TERMINATA. ");

        }

        private void SmatisciCoda()
        {
            int Id_Biglietteria = Convert.ToInt32(Thread.CurrentThread.Name);
            int PosEstratto = 0;
            if (GetPostiStadioDisponibili()>0 && GetClientiDisponibili(Id_Biglietteria)>0)
            {
                do
                {
                    PosEstratto = rnd.Next(0, Cl.Length);
                } while (Cl[PosEstratto].IdBiglietteria != Id_Biglietteria ||
                         Cl[PosEstratto].Smaltito == true);
                Cl[PosEstratto].Smaltito = true;
                Console.WriteLine(Cl[PosEstratto].IdBiglietteria.ToString() + "  \n" + Cl[PosEstratto].IdCliente.ToString());
                Thread.Sleep(1000);
               
            }
            if (GetPostiStadioDisponibili() > 0 && GetClientiDisponibili(Id_Biglietteria) > 0)
            {
                SmatisciCoda();
            }

        }
        private int GetPostiStadioDisponibili()
        {
            lock (lock_campo)//uso per far eseguire un thread per vota queste isruzioni
            {
                int cont = 0;
                for (int i = 0; i < Ps.Length; i++)
                {
                    if (Ps[i].IdCliente == 0)
                    {
                        cont++;
                    }
                }
                return cont;
            }
            
        }

        private int GetClientiDisponibili(int id)
        {
            int cont = 0;
            for (int i = 0; i < Cl.Length; i++)
            {
                if (Cl[i].Smaltito == false && Cl[i].IdBiglietteria == id)
                {
                    cont++;
                }
            }
            return cont;
        }

        private void SetLabel(Label lbl,string msg)
        {
            BeginInvoke((MethodInvoker)delegate ()
            {
                lbl.Text = msg;
            });
        }
    }    
}
