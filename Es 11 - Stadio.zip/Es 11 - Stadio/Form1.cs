﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Es_11___Stadio
{
    public partial class Form1 : Form
    {
        public struct BigliettiAcquistati
        {
            public string idCliente, idCassa; // es: idCliente => cli_153 idCassa => OVEST
            public int nBiglietti;
            public DateTime oraAcquisto;
        }
        public BigliettiAcquistati[] bAcquistati;

        const int BIGLIETTERIE = 4;

        volatile Random rnd;

        volatile int nPosti;
        volatile int nClienti;
        volatile int posBiglietto = 0;
        volatile int idClienti = 1;

        volatile string[] nomeBiglietterie = new string[] { "nord", "sud", "ovest", "est" };
        volatile object lock_vendita = new object();

        Thread arbitro;
        Thread[] Biglietto;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamWriter sr = new StreamWriter("nord.txt", false);
            sr.WriteLine("BIGLIETTERIA NORD");
            sr.WriteLine("ID CLIENTE - ID CASSA - N BIGLIETTI - ORA ACQUISTO");
            sr.Close();

            sr = new StreamWriter("sud.txt", false);
            sr.WriteLine("BIGLIETTERIA SUD");
            sr.WriteLine("ID CLIENTE - ID CASSA - N BIGLIETTI - ORA ACQUISTO");
            sr.Close();

            sr = new StreamWriter("ovest.txt", false);
            sr.WriteLine("BIGLIETTERIA OVEST");
            sr.WriteLine("ID CLIENTE - ID CASSA - N BIGLIETTI - ORA ACQUISTO");
            sr.Close();

            sr = new StreamWriter("est.txt", false);
            sr.WriteLine("BIGLIETTERIA EST");
            sr.WriteLine("ID CLIENTE - ID CASSA - N BIGLIETTI - ORA ACQUISTO");
            sr.Close();
        }

        private void btnAvvia_Click(object sender, EventArgs e)
        {
            try
            {
                nPosti = Convert.ToInt32(txtPostiDisponibili.Text);
                nClienti = Convert.ToInt32(txtPotenzialiClienti.Text);

                rnd = new Random();

                setLabel(lblStatus, "ACQUISTO IN CORSO");
                btnAvvia.Enabled = false;
                arbitro = new Thread(GestoreBiglietti);
                arbitro.Start();
            }
            catch
            {
                MessageBox.Show("Compilare correttamente i dati");
            }
        }

        private void GestoreBiglietti()
        {
            Biglietto = new Thread[BIGLIETTERIE];
            bAcquistati = new BigliettiAcquistati[nPosti];

            do
            {
                int n = rnd.Next(0, 4);
                Biglietto[n] = new Thread(vendita);
                Biglietto[n].Name = nomeBiglietterie[n];
                Biglietto[n].Start();
            } while (nClienti > 0 && nPosti>0);
            setLabel(lblStatus, "FINITO");
        }

        private void vendita()
        {
            lock(lock_vendita){
                if(nClienti > 0)
                {
                    Thread.Sleep(100);
                    int n = rnd.Next(0, 2);     //biglietti di un cliente
                   // MessageBox.Show(Thread.CurrentThread.Name + " - " + idClienti.ToString() + " - " + n.ToString());
                    if (nPosti >= n)
                    {
                        if (n > 0)
                        {
                            bAcquistati[posBiglietto].idCliente = "cli_" + idClienti;
                            bAcquistati[posBiglietto].idCassa = Thread.CurrentThread.Name;
                            bAcquistati[posBiglietto].nBiglietti = n;
                            bAcquistati[posBiglietto].oraAcquisto = DateTime.Now;
                            nPosti -= n;

                            SalvaBiglietto(Thread.CurrentThread.Name, bAcquistati[posBiglietto]);
                            posBiglietto++;
                        }

                        idClienti++;
                        nClienti--;
                    }
                    else
                        return;
                }
            }
        }

        private void SalvaBiglietto(string s, BigliettiAcquistati bAcq)
        {
            StreamWriter sr = new StreamWriter(s + ".txt", true);
            sr.WriteLine(bAcq.idCliente + " - " + bAcq.idCassa + " - " + bAcq.nBiglietti + " - " + bAcq.oraAcquisto);
            sr.Close();
        }

        private void lblNord_Click(object sender, EventArgs e)
        {
            // VISUALIZZA TXT BIGLIETTI NORD
            Process.Start("nord.txt");
        }

        private void lblEst_Click(object sender, EventArgs e)
        {
            // VISUALIZZA TXT BIGLIETTI EST
            Process.Start("est.txt");
        }

        private void lblSud_Click(object sender, EventArgs e)
        {
            // VISUALIZZA TXT BIGLIETTI SUD
            Process.Start("sud.txt");
        }

        private void lblOvest_Click(object sender, EventArgs e)
        {
            // VISUALIZZA TXT BIGLIETTI OVEST
            Process.Start("ovest.txt");
        }

        private void setLabel(Label lbl, string msg)
        {
            BeginInvoke((MethodInvoker)delegate ()
            {
                lbl.Text = msg;
            });
        }
    }
}
